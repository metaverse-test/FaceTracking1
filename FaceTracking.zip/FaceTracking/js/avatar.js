/**
 * avatar.js
 * ---------------------------------------------------------------------------
 * Charge un fichier GLB/GLTF et détecte AUTOMATIQUEMENT :
 *   - tous les meshes porteurs de morph targets (blendshapes) ;
 *   - le bone de tête et les bones des yeux, par correspondance de nom.
 *
 * Aucun nom de mesh ou de modèle n'est codé en dur : ce module fonctionne à
 * l'identique quel que soit l'avatar GLB fourni, du moment qu'il respecte
 * les conventions glTF standard (morphTargetDictionary, bones nommés).
 */

import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { DRACOLoader } from 'three/addons/loaders/DRACOLoader.js';
import { nameMatchesKeywords, getFileBaseName } from './utils.js';

// Gardée synchronisée avec la version de Three.js déclarée dans l'import map
// de index.html, pour que le décodeur Draco corresponde toujours au runtime
// réellement chargé par le navigateur.
const THREE_VERSION = '0.184.0';
const DRACO_DECODER_PATH = `https://unpkg.com/three@${THREE_VERSION}/examples/jsm/libs/draco/gltf/`;

// Mots-clés (normalisés : minuscules, sans séparateurs) utilisés pour
// retrouver les bones importants quelle que soit la convention de nommage
// de l'avatar (Mixamo, Ready Player Me, Blender, VRoid...).
const HEAD_KEYWORDS = ['head'];
const LEFT_EYE_KEYWORDS = ['lefteye', 'eyeleft', 'eyel', 'leye'];
const RIGHT_EYE_KEYWORDS = ['righteye', 'eyeright', 'eyer', 'reye'];

/**
 * Représente un avatar chargé et analysé : sa racine Three.js, les meshes
 * porteurs de morph targets, et les bones de tête/yeux trouvés (le cas
 * échéant). Une même instance est réutilisée pendant toute la session, afin
 * de ne jamais re-parcourir la scène après le chargement initial.
 */
export class Avatar {
  constructor() {
    /** @type {THREE.Object3D|null} */
    this.root = null;
    this.gltf = null;
    this.modelName = '';
    /** @type {{mesh: THREE.Mesh, dictionary: Record<string, number>}[]} */
    this.morphMeshes = [];
    /** @type {Set<string>} Noms uniques de blendshapes toutes meshes confondues. */
    this.blendshapeNames = new Set();
    /** @type {THREE.Bone|null} */
    this.headBone = null;
    /** @type {THREE.Bone|null} */
    this.leftEyeBone = null;
    /** @type {THREE.Bone|null} */
    this.rightEyeBone = null;
  }
}

// Le GLTFLoader (et son DRACOLoader associé) est coûteux à instancier et
// n'a besoin d'exister qu'une seule fois pour toute l'application.
let sharedLoader = null;

function getGLTFLoader() {
  if (sharedLoader) return sharedLoader;

  const dracoLoader = new DRACOLoader();
  dracoLoader.setDecoderPath(DRACO_DECODER_PATH);

  sharedLoader = new GLTFLoader();
  sharedLoader.setDRACOLoader(dracoLoader);
  return sharedLoader;
}

/**
 * Charge un modèle GLB/GLTF et retourne un {@link Avatar} entièrement
 * analysé (morph targets + bones détectés). Ne lève jamais d'exception au
 * sens "crash silencieux inexpliqué" : les erreurs réseau/format remontent
 * normalement via la Promise rejetée, à charge pour l'appelant de les
 * afficher proprement dans l'interface (voir script.js).
 *
 * @param {string} url
 * @param {(event: ProgressEvent) => void} [onProgress]
 * @returns {Promise<Avatar>}
 */
export async function loadAvatar(url, onProgress) {
  const loader = getGLTFLoader();
  const gltf = await loader.loadAsync(url, onProgress);

  const avatar = new Avatar();
  avatar.gltf = gltf;
  avatar.root = gltf.scene;
  avatar.modelName = getFileBaseName(url);

  avatar.root.traverse((object) => {
    if (object.isMesh) {
      // Les morph targets déplacent les sommets sans mettre à jour la
      // bounding box du mesh : sans désactiver le frustum culling, Three.js
      // peut faire disparaître le visage à tort dès que la caméra se
      // rapproche ou que la tête tourne.
      object.frustumCulled = false;
      object.castShadow = true;
      object.receiveShadow = true;

      const dictionary = object.morphTargetDictionary;
      if (dictionary && object.morphTargetInfluences && Object.keys(dictionary).length > 0) {
        avatar.morphMeshes.push({ mesh: object, dictionary });
        Object.keys(dictionary).forEach((name) => avatar.blendshapeNames.add(name));
      }
    }

    if (object.isBone) {
      if (!avatar.headBone && nameMatchesKeywords(object.name, HEAD_KEYWORDS)) {
        avatar.headBone = object;
      }
      if (!avatar.leftEyeBone && nameMatchesKeywords(object.name, LEFT_EYE_KEYWORDS)) {
        avatar.leftEyeBone = object;
      }
      if (!avatar.rightEyeBone && nameMatchesKeywords(object.name, RIGHT_EYE_KEYWORDS)) {
        avatar.rightEyeBone = object;
      }
    }
  });

  if (avatar.morphMeshes.length === 0) {
    console.warn(
      `[Avatar] Aucun morph target détecté dans "${avatar.modelName}". ` +
      'Vérifiez que le modèle exporte bien des blendshapes (ARKit ou autre).'
    );
  }
  if (!avatar.headBone) {
    console.warn(
      `[Avatar] Aucun bone "Head" détecté dans "${avatar.modelName}" — ` +
      'la rotation de tête sera appliquée à l\'objet racine du modèle.'
    );
  }

  return avatar;
}
