/**
 * controls.js
 * ---------------------------------------------------------------------------
 * Configure OrbitControls pour permettre à l'utilisateur d'inspecter
 * librement l'avatar (rotation, zoom) à la souris comme au doigt.
 */

import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

/**
 * @param {THREE.PerspectiveCamera} camera
 * @param {HTMLElement} domElement
 * @returns {OrbitControls}
 */
export function createOrbitControls(camera, domElement) {
  const controls = new OrbitControls(camera, domElement);

  controls.enableDamping = true;
  controls.dampingFactor = 0.08;
  controls.rotateSpeed = 0.7;
  controls.minDistance = 0.15;
  controls.maxDistance = 5;
  controls.maxPolarAngle = Math.PI * 0.85;
  controls.target.set(0, 1.5, 0);

  controls.update();
  return controls;
}
