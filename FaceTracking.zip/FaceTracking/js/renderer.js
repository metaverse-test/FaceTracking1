/**
 * renderer.js
 * ---------------------------------------------------------------------------
 * Crée le WebGLRenderer avec des réglages de rendu modernes (espace colorimétrique
 * sRGB, tone mapping filmique, ombres douces). Three.js utilise WebGL2 par
 * défaut depuis la r118, aucune configuration manuelle n'est nécessaire.
 */

import * as THREE from 'three';

/**
 * @param {HTMLCanvasElement} canvas
 * @returns {THREE.WebGLRenderer}
 */
export function createRenderer(canvas) {
  const renderer = new THREE.WebGLRenderer({
    canvas,
    antialias: true,
    alpha: false,
    powerPreference: 'high-performance',
  });

  // Limiter le pixel ratio évite de faire ramer les mobiles à écran "Retina"
  // (Android/iOS peuvent monter à 3+), sans dégrader visiblement le rendu.
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderer.setSize(window.innerWidth, window.innerHeight);

  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.1;

  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;

  return renderer;
}

/**
 * @param {THREE.WebGLRenderer} renderer
 * @param {number} width
 * @param {number} height
 */
export function resizeRenderer(renderer, width, height) {
  renderer.setSize(width, height);
}
