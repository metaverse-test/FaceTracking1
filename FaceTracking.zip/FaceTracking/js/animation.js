/**
 * animation.js
 * ---------------------------------------------------------------------------
 * Cœur temps réel de l'application. Découple volontairement deux rythmes :
 *   - la détection MediaPipe, qui arrive de façon irrégulière (elle peut
 *     tourner plus lentement que l'affichage, surtout sur mobile) ;
 *   - la boucle de rendu (requestAnimationFrame), qui doit rester fluide à
 *     60 FPS même entre deux détections.
 *
 * `setBlendshapeTargets()` / `setHeadTransform()` enregistrent uniquement
 * les valeurs CIBLES les plus récentes. `update(deltaSeconds)`, appelé à
 * chaque frame de rendu, interpole ("damping" exponentiel + slerp) entre la
 * valeur courante et la cible pour obtenir un mouvement lissé, puis écrit le
 * résultat dans les morphTargetInfluences et les quaternions des bones.
 *
 * Aucune allocation d'objet n'a lieu dans update() : tous les vecteurs /
 * quaternions / matrices utilisés sont créés une seule fois dans le
 * constructeur et réutilisés à chaque frame.
 */

import * as THREE from 'three';
import { damp, warnOnce } from './utils.js';

const DEG2RAD = Math.PI / 180;

export class AnimationController {
  /**
   * @param {import('./avatar.js').Avatar} avatar
   * @param {Map<string, {mesh: THREE.Mesh, index: number}[]>} blendshapeMap
   * @param {object} [options]
   * @param {number} [options.blendshapeSmoothing] Vitesse de lissage des blendshapes.
   * @param {number} [options.headSmoothing] Vitesse de lissage de la rotation de tête.
   * @param {number} [options.eyeSmoothing] Vitesse de lissage du regard.
   * @param {number} [options.eyeMaxAngleDeg] Amplitude max de rotation des yeux, en degrés.
   * @param {boolean} [options.mirrorHeadYaw] Inverse le lacet/roulis de tête (voir README).
   */
  constructor(avatar, blendshapeMap, options = {}) {
    this.avatar = avatar;
    this.blendshapeMap = blendshapeMap;

    this.blendshapeLambda = options.blendshapeSmoothing ?? 22;
    this.headLambda = options.headSmoothing ?? 14;
    this.eyeLambda = options.eyeSmoothing ?? 18;
    this.eyeMaxAngle = (options.eyeMaxAngleDeg ?? 26) * DEG2RAD;
    this.mirrorHeadYaw = options.mirrorHeadYaw ?? false;

    // --- État des blendshapes -------------------------------------------
    // Pré-rempli une seule fois avec toutes les clés connues du modèle :
    // plus aucune insertion dans ces Maps après le constructeur, donc plus
    // aucune allocation liée aux blendshapes pendant l'animation.
    this.currentValues = new Map();
    this.targetValues = new Map();
    for (const name of blendshapeMap.keys()) {
      this.currentValues.set(name, 0);
      this.targetValues.set(name, 0);
    }
    // Scores bruts MediaPipe (toutes catégories, y compris celles absentes
    // du modèle) : nécessaires pour piloter les bones des yeux même quand
    // l'avatar n'a pas de morph targets "eyeLook*".
    this._rawScores = new Map();

    // --- Rotation de tête -------------------------------------------------
    // Cible "bone Head" si présent, sinon repli sur l'objet racine du
    // modèle (le "mesh principal" demandé dans le cahier des charges).
    this.headTarget = avatar.headBone || avatar.root;
    this._hasHeadBone = Boolean(avatar.headBone);
    this.headRest = this.headTarget.quaternion.clone();
    this._headCurrent = this.headRest.clone();
    this._headHasTarget = false;

    // --- Regard (yeux) ------------------------------------------------
    this.leftEyeRest = avatar.leftEyeBone ? avatar.leftEyeBone.quaternion.clone() : null;
    this.rightEyeRest = avatar.rightEyeBone ? avatar.rightEyeBone.quaternion.clone() : null;
    this._leftEyeCurrent = this.leftEyeRest ? this.leftEyeRest.clone() : null;
    this._rightEyeCurrent = this.rightEyeRest ? this.rightEyeRest.clone() : null;
    this._leftEyeTarget = new THREE.Quaternion();
    this._rightEyeTarget = new THREE.Quaternion();

    // --- Scratch objects réutilisés à chaque frame (zéro allocation) ---
    this._matrix = new THREE.Matrix4();
    this._extractedQuat = new THREE.Quaternion();
    this._scratchPos = new THREE.Vector3();
    this._scratchScale = new THREE.Vector3();
    this._scratchEuler = new THREE.Euler();
    this._scratchQuatA = new THREE.Quaternion();
    this._scratchQuatB = new THREE.Quaternion();
  }

  /**
   * Enregistre les scores de blendshapes les plus récents envoyés par
   * MediaPipe. Pour chaque catégorie : si le nom existe dans le modèle,
   * elle devient la nouvelle cible ; sinon elle est ignorée avec un simple
   * avertissement (affiché une seule fois par nom, jamais à chaque frame).
   *
   * @param {{categoryName: string, score: number}[]} categories
   */
  setBlendshapeTargets(categories) {
    for (let i = 0; i < categories.length; i++) {
      const name = categories[i].categoryName;
      const score = categories[i].score;

      this._rawScores.set(name, score);

      if (name === '_neutral') continue;

      if (this.targetValues.has(name)) {
        this.targetValues.set(name, score);
      } else {
        warnOnce(
          `missing-blendshape:${name}`,
          `[Animation] Le blendshape "${name}" n'existe pas sur ce modèle — ignoré.`
        );
      }
    }

    this._updateEyeTargets();
  }

  /** Calcule les quaternions cibles des yeux à partir des scores eyeLook*. */
  _updateEyeTargets() {
    const score = (name) => this._rawScores.get(name) || 0;

    if (this.avatar.leftEyeBone) {
      const yaw = (score('eyeLookOutLeft') - score('eyeLookInLeft')) * this.eyeMaxAngle;
      const pitch = (score('eyeLookDownLeft') - score('eyeLookUpLeft')) * this.eyeMaxAngle;
      this._scratchEuler.set(pitch, yaw, 0);
      this._leftEyeTarget.setFromEuler(this._scratchEuler);
    }

    if (this.avatar.rightEyeBone) {
      const yaw = (score('eyeLookInRight') - score('eyeLookOutRight')) * this.eyeMaxAngle;
      const pitch = (score('eyeLookDownRight') - score('eyeLookUpRight')) * this.eyeMaxAngle;
      this._scratchEuler.set(pitch, yaw, 0);
      this._rightEyeTarget.setFromEuler(this._scratchEuler);
    }
  }

  /**
   * Enregistre la matrice de transformation faciale (4x4, column-major)
   * fournie par MediaPipe pour la frame courante, et en extrait la
   * rotation cible.
   *
   * @param {Float32Array|number[]} matrixArray Tableau de 16 nombres.
   */
  setHeadTransform(matrixArray) {
    this._matrix.fromArray(matrixArray);
    this._matrix.decompose(this._scratchPos, this._extractedQuat, this._scratchScale);

    // Selon la convention de votre avatar, la rotation peut apparaître
    // inversée (lacet/roulis) une fois appliquée. `mirrorHeadYaw` permet de
    // corriger cela sans toucher au reste du code — voir le README.
    if (this.mirrorHeadYaw) {
      this._extractedQuat.y *= -1;
      this._extractedQuat.z *= -1;
    }

    this._headHasTarget = true;
  }

  /**
   * À appeler une fois par frame de rendu (requestAnimationFrame), que de
   * nouvelles données MediaPipe soient arrivées ou non : c'est ce qui
   * garantit un rendu fluide même si la détection tourne plus lentement
   * que l'affichage.
   *
   * @param {number} deltaSeconds Temps écoulé depuis la frame précédente.
   */
  update(deltaSeconds) {
    // Protection contre les gros sauts de deltaTime (onglet remis au
    // premier plan après une pause, etc.) qui feraient "sauter" l'avatar.
    const dt = Math.min(Math.max(deltaSeconds, 0), 0.1);

    this._updateBlendshapes(dt);
    this._updateHeadRotation(dt);
    this._updateEyeRotation(dt);
  }

  _updateBlendshapes(dt) {
    for (const [name, entries] of this.blendshapeMap) {
      const target = this.targetValues.get(name);
      const current = damp(this.currentValues.get(name), target, this.blendshapeLambda, dt);
      this.currentValues.set(name, current);

      for (let i = 0; i < entries.length; i++) {
        entries[i].mesh.morphTargetInfluences[entries[i].index] = current;
      }
    }
  }

  _updateHeadRotation(dt) {
    if (!this._headHasTarget) return;

    const t = 1 - Math.exp(-this.headLambda * dt);
    const desired = this._scratchQuatA.copy(this.headRest).multiply(this._extractedQuat);
    this._headCurrent.slerp(desired, t);
    this.headTarget.quaternion.copy(this._headCurrent);
  }

  _updateEyeRotation(dt) {
    const t = 1 - Math.exp(-this.eyeLambda * dt);

    if (this.avatar.leftEyeBone) {
      const desired = this._scratchQuatB.copy(this.leftEyeRest).multiply(this._leftEyeTarget);
      this._leftEyeCurrent.slerp(desired, t);
      this.avatar.leftEyeBone.quaternion.copy(this._leftEyeCurrent);
    }

    if (this.avatar.rightEyeBone) {
      const desired = this._scratchQuatB.copy(this.rightEyeRest).multiply(this._rightEyeTarget);
      this._rightEyeCurrent.slerp(desired, t);
      this.avatar.rightEyeBone.quaternion.copy(this._rightEyeCurrent);
    }
  }
}
