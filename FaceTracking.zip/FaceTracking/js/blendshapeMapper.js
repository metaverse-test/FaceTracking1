/**
 * blendshapeMapper.js
 * ---------------------------------------------------------------------------
 * Construit, UNE SEULE FOIS après le chargement de l'avatar, la table de
 * correspondance entre un nom de blendshape (ex. "eyeBlinkLeft") et la ou
 * les entrées {mesh, index} à mettre à jour dans morphTargetInfluences.
 *
 * C'est ce module qui rend le mapping "automatique" : il ne connaît aucun
 * nom de blendshape à l'avance, il se contente d'indexer ce que l'avatar
 * expose réellement dans ses morphTargetDictionary. La correspondance avec
 * les catégories envoyées par MediaPipe se fait ensuite par simple égalité
 * de nom (voir animation.js), sans aucune liste codée en dur.
 */

/**
 * @param {{mesh: THREE.Mesh, dictionary: Record<string, number>}[]} morphMeshes
 * @returns {Map<string, {mesh: THREE.Mesh, index: number}[]>}
 *   Table nom de blendshape -> liste des (mesh, index) à animer. Une liste
 *   plutôt qu'une seule entrée, car plusieurs meshes d'un même avatar
 *   (ex. "Tête" et "Dents") peuvent partager le même nom de blendshape.
 */
export function buildBlendshapeMap(morphMeshes) {
  const map = new Map();

  for (const { mesh, dictionary } of morphMeshes) {
    for (const name of Object.keys(dictionary)) {
      const index = dictionary[name];
      if (!map.has(name)) {
        map.set(name, []);
      }
      map.get(name).push({ mesh, index });
    }
  }

  return map;
}
