/**
 * utils.js
 * ---------------------------------------------------------------------------
 * Fonctions utilitaires génériques, sans dépendance à un modèle ou un avatar
 * particulier. Toutes les fonctions ici sont pures ou à effet de bord minime
 * (logs), afin de rester faciles à tester et à réutiliser.
 */

import * as THREE from 'three';

/** Contraint `value` entre `min` et `max`. */
export function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

/**
 * Interpolation exponentielle indépendante du framerate ("damping").
 * Contrairement à un lerp classique (current + (target-current) * t), ce
 * calcul donne un résultat cohérent même si le delta-time varie (baisse de
 * FPS, onglet en arrière-plan, etc.), ce qui est essentiel pour un rendu
 * temps réel fluide.
 *
 * @param {number} current  Valeur actuelle.
 * @param {number} target   Valeur cible.
 * @param {number} lambda   Vitesse de convergence (plus grand = plus réactif).
 * @param {number} deltaTime Temps écoulé depuis la dernière frame, en secondes.
 */
export function damp(current, target, lambda, deltaTime) {
  return current + (target - current) * (1 - Math.exp(-lambda * deltaTime));
}

/**
 * Vérifie si `name` correspond à l'un des mots-clés fournis, indépendamment
 * de la casse et des séparateurs (_, -, ., espace...). Utilisé pour retrouver
 * automatiquement les bones "Head", "LeftEye", "RightEye" quelle que soit la
 * convention de nommage de l'avatar (Mixamo, Ready Player Me, etc.).
 *
 * @param {string} name
 * @param {string[]} keywords Mots-clés déjà en minuscules, sans séparateurs.
 */
export function nameMatchesKeywords(name, keywords) {
  if (!name) return false;
  const normalized = name.toLowerCase().replace(/[^a-z0-9]/g, '');
  return keywords.some((keyword) => normalized.includes(keyword));
}

/** Extrait le nom de fichier sans extension à partir d'un chemin/URL. */
export function getFileBaseName(path) {
  const fileName = path.split('/').pop() || path;
  return fileName.replace(/\.(glb|gltf)$/i, '');
}

/**
 * Fabrique un "warnOnce" : un logger qui n'affiche jamais deux fois le même
 * message. Essentiel pour respecter la contrainte "le projet ne doit jamais
 * planter / jamais spammer la console" quand un blendshape est absent d'un
 * modèle, ce qui peut concerner des dizaines de catégories à chaque frame.
 */
export function createWarnOnce() {
  const seen = new Set();
  return function warnOnce(key, message) {
    if (seen.has(key)) return;
    seen.add(key);
    console.warn(message);
  };
}

// Instance partagée par défaut : suffisante pour la plupart des usages dans
// ce projet (un seul avatar, une seule session de suivi à la fois).
export const warnOnce = createWarnOnce();

/**
 * Fabrique un compteur de FPS peu coûteux : il n'effectue un calcul (et ne
 * renvoie une valeur) qu'une fois toutes les `sampleIntervalMs`, afin de ne
 * jamais toucher le DOM à chaque frame.
 *
 * @param {number} sampleIntervalMs
 * @returns {(nowMs: number) => number|null} fonction à appeler à chaque frame
 */
export function createFPSMeter(sampleIntervalMs = 500) {
  let frameCount = 0;
  let elapsed = 0;
  let lastTime = null;

  return function tick(nowMs) {
    if (lastTime === null) {
      lastTime = nowMs;
      return null;
    }
    const delta = nowMs - lastTime;
    lastTime = nowMs;
    frameCount += 1;
    elapsed += delta;

    if (elapsed >= sampleIntervalMs) {
      const fps = Math.round((frameCount * 1000) / elapsed);
      frameCount = 0;
      elapsed = 0;
      return fps;
    }
    return null;
  };
}

/**
 * Centre et cadre automatiquement la caméra sur un objet 3D, quelle que
 * soit son échelle réelle (mètres, centimètres, unités arbitraires...).
 * Permet de charger n'importe quel avatar GLB sans avoir à deviner une
 * position de caméra codée en dur.
 *
 * @param {THREE.PerspectiveCamera} camera
 * @param {import('three/addons/controls/OrbitControls.js').OrbitControls} controls
 * @param {THREE.Object3D} object3D
 * @param {number} paddingFactor Marge autour du modèle (1 = cadrage serré).
 */
export function frameCameraOnObject(camera, controls, object3D, paddingFactor = 1.6) {
  const box = new THREE.Box3().setFromObject(object3D);
  if (box.isEmpty()) return;

  const size = box.getSize(new THREE.Vector3());
  const center = box.getCenter(new THREE.Vector3());
  const maxDimension = Math.max(size.x, size.y, size.z) || 1;
  const fovInRadians = (camera.fov * Math.PI) / 180;
  const distance = (maxDimension * paddingFactor) / (2 * Math.tan(fovInRadians / 2));

  camera.position.set(center.x, center.y, center.z + distance);
  camera.near = Math.max(distance / 100, 0.01);
  camera.far = distance * 100;
  camera.updateProjectionMatrix();

  controls.target.copy(center);
  controls.minDistance = distance * 0.2;
  controls.maxDistance = distance * 4;
  controls.update();
}
