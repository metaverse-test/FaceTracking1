/**
 * mediapipe.js
 * ---------------------------------------------------------------------------
 * Encapsule l'intégration de MediaPipe Tasks Vision (Face Landmarker) :
 * initialisation du runtime WASM + modèle, gestion de la webcam, et boucle
 * de détection vidéo optimisée (une seule inférence par frame vidéo réelle,
 * jamais deux fois sur la même image).
 *
 * Toutes les méthodes publiques sont conçues pour ne jamais lever
 * d'exception non gérée vers l'appelant : les échecs sont soit renvoyés
 * (Promise rejetée pour init()/enableCamera(), que script.js affiche dans
 * l'interface), soit absorbés avec un simple avertissement (detect()).
 */

import { FaceLandmarker, FilesetResolver } from 'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@latest/vision_bundle.mjs';
import { warnOnce } from './utils.js';

const WASM_BASE_URL = 'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@latest/wasm';
const MODEL_URL =
  'https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task';

export class FaceTracker {
  constructor() {
    /** @type {FaceLandmarker|null} */
    this.landmarker = null;
    this.isReady = false;
    /** @type {MediaStream|null} */
    this.stream = null;

    this._lastVideoTime = -1;
    this._lastResult = null;
  }

  /**
   * Initialise le runtime WASM et charge le modèle Face Landmarker.
   * Tente d'abord l'accélération GPU (plus rapide, importante sur mobile),
   * puis se rabat automatiquement sur le CPU si le GPU échoue (drivers
   * incomplets, navigateur sans WebGL adéquat, etc.) — c'est ce qui permet
   * au projet de fonctionner sur un maximum d'appareils Android sans
   * configuration manuelle.
   */
  async init() {
    const filesetResolver = await FilesetResolver.forVisionTasks(WASM_BASE_URL);

    const options = {
      baseOptions: {
        modelAssetPath: MODEL_URL,
        delegate: 'GPU',
      },
      runningMode: 'VIDEO',
      numFaces: 1,
      outputFaceBlendshapes: true,
      outputFacialTransformationMatrixes: true,
    };

    try {
      this.landmarker = await FaceLandmarker.createFromOptions(filesetResolver, options);
    } catch (gpuError) {
      console.warn('[MediaPipe] Délégué GPU indisponible, bascule sur CPU.', gpuError);
      options.baseOptions.delegate = 'CPU';
      this.landmarker = await FaceLandmarker.createFromOptions(filesetResolver, options);
    }

    this.isReady = true;
  }

  /**
   * Demande l'accès à la webcam et démarre le flux vidéo dans `videoEl`.
   * @param {HTMLVideoElement} videoEl
   */
  async enableCamera(videoEl) {
    if (this.stream) return;

    this.stream = await navigator.mediaDevices.getUserMedia({
      audio: false,
      video: {
        facingMode: 'user',
        width: { ideal: 640 },
        height: { ideal: 480 },
      },
    });

    videoEl.srcObject = this.stream;
    await videoEl.play();
  }

  /**
   * Coupe la webcam et libère les pistes vidéo (batterie/vie privée).
   * @param {HTMLVideoElement} [videoEl]
   */
  disableCamera(videoEl) {
    if (this.stream) {
      this.stream.getTracks().forEach((track) => track.stop());
      this.stream = null;
    }
    if (videoEl) {
      videoEl.srcObject = null;
    }
    this._lastVideoTime = -1;
    this._lastResult = null;
  }

  /**
   * Lance une détection sur l'image vidéo courante, si et seulement si une
   * nouvelle frame est disponible depuis le dernier appel (évite les
   * inférences redondantes lorsque la boucle de rendu tourne plus vite que
   * la caméra). Ne lève jamais : renvoie `null` en cas d'échec ou d'absence
   * de nouvelle frame réutilisable.
   *
   * @param {HTMLVideoElement} videoEl
   * @param {number} nowMs
   * @returns {import('@mediapipe/tasks-vision').FaceLandmarkerResult|null}
   */
  detect(videoEl, nowMs) {
    if (!this.isReady || !videoEl || videoEl.readyState < 2) {
      return null;
    }
    if (videoEl.currentTime === this._lastVideoTime) {
      return this._lastResult;
    }
    this._lastVideoTime = videoEl.currentTime;

    try {
      this._lastResult = this.landmarker.detectForVideo(videoEl, nowMs);
    } catch (error) {
      warnOnce('mediapipe-detect-error', `[MediaPipe] Erreur pendant la détection : ${error.message}`);
      this._lastResult = null;
    }

    return this._lastResult;
  }
}
