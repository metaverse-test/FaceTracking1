/**
 * camera.js
 * ---------------------------------------------------------------------------
 * Crée et met à jour la caméra perspective. La position initiale est
 * volontairement approximative : `utils.frameCameraOnObject()` la recadre
 * précisément une fois l'avatar chargé, quelle que soit son échelle.
 */

import * as THREE from 'three';

/**
 * @param {number} aspect Ratio largeur/hauteur du viewport.
 * @returns {THREE.PerspectiveCamera}
 */
export function createCamera(aspect) {
  const camera = new THREE.PerspectiveCamera(32, aspect, 0.01, 100);
  camera.position.set(0, 1.55, 0.6);
  return camera;
}

/**
 * @param {THREE.PerspectiveCamera} camera
 * @param {number} width
 * @param {number} height
 */
export function updateCameraAspect(camera, width, height) {
  camera.aspect = width / height;
  camera.updateProjectionMatrix();
}
