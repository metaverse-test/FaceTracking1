/**
 * lights.js
 * ---------------------------------------------------------------------------
 * Met en place l'éclairage de la scène. Deux modes :
 *  - si `hdrPath` est fourni et se charge correctement, l'environnement HDRI
 *    sert de source de lumière et de reflets (rendu le plus réaliste) ;
 *  - sinon (ou en cas d'échec de chargement), un rig 3 points + lumière
 *    d'ambiance sert de repli, pour ne jamais laisser l'avatar dans le noir.
 */

import * as THREE from 'three';
import { RGBELoader } from 'three/addons/loaders/RGBELoader.js';

/**
 * @param {THREE.Scene} scene
 * @param {THREE.WebGLRenderer} renderer
 * @param {string|null} hdrPath Chemin vers un fichier .hdr, ou null.
 */
export async function setupLighting(scene, renderer, hdrPath = null) {
  if (hdrPath) {
    try {
      const texture = await new RGBELoader().loadAsync(hdrPath);
      texture.mapping = THREE.EquirectangularReflectionMapping;
      scene.environment = texture;
      // Une petite lumière directionnelle en plus de l'HDRI ajoute un
      // reflet ("catchlight") net dans les yeux, que l'irradiance diffuse
      // d'un environnement seul ne produit pas toujours.
      addCatchlight(scene);
      return;
    } catch (error) {
      console.warn(
        `[Lights] Impossible de charger l'environnement HDRI "${hdrPath}", ` +
        'utilisation de l\'éclairage par défaut à la place.',
        error
      );
    }
  }

  addStudioLights(scene);
}

/** Rig 3 points (clé / remplissage / contre-jour) + ambiance, façon studio portrait. */
function addStudioLights(scene) {
  const key = new THREE.DirectionalLight(0xfff2df, 2.4);
  key.position.set(0.6, 1.3, 1.4);
  key.castShadow = true;
  key.shadow.mapSize.set(1024, 1024);
  key.shadow.camera.near = 0.1;
  key.shadow.camera.far = 10;
  scene.add(key);

  const fill = new THREE.DirectionalLight(0xcfe3ff, 0.8);
  fill.position.set(-1.2, 0.5, 0.9);
  scene.add(fill);

  const rim = new THREE.DirectionalLight(0xffffff, 1.2);
  rim.position.set(-0.3, 1.5, -1.4);
  scene.add(rim);

  const ambient = new THREE.HemisphereLight(0x8fa2bd, 0x0e0f13, 0.55);
  scene.add(ambient);
}

function addCatchlight(scene) {
  const catchlight = new THREE.DirectionalLight(0xffffff, 0.35);
  catchlight.position.set(0.3, 1.0, 1.3);
  scene.add(catchlight);
}
