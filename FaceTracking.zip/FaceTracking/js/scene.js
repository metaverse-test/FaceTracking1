/**
 * scene.js
 * ---------------------------------------------------------------------------
 * Crée la THREE.Scene de base. Séparé du reste pour rester facilement
 * remplaçable (fog, skybox, environnement...) sans toucher au reste de
 * l'application.
 */

import * as THREE from 'three';

/**
 * @returns {THREE.Scene}
 */
export function createScene() {
  const scene = new THREE.Scene();

  // Fond sombre neutre : sert de repli tant qu'aucun environnement HDRI
  // n'est chargé (voir lights.js), et reste cohérent avec le thème de
  // l'interface même si un HDRI est utilisé uniquement pour les reflets.
  scene.background = new THREE.Color(0x0a0c10);

  return scene;
}
