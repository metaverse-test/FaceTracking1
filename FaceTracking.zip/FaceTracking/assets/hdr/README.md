# assets/hdr/

Dossier optionnel pour un environnement `.hdr` (reflets et éclairage plus
réalistes). Placez-y un fichier équirectangulaire (ex. `studio.hdr`) puis
indiquez son chemin dans `CONFIG.hdrPath` (`script.js`) :

```js
hdrPath: 'assets/hdr/studio.hdr',
```

Si `hdrPath` reste à `null` (par défaut), l'éclairage studio intégré
(`js/lights.js`) est utilisé automatiquement — aucun fichier requis ici.
