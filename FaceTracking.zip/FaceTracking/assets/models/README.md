# assets/models/

Placez ici votre avatar au format `.glb`, nommé `LuciaHead.glb` par défaut
(ou modifiez `CONFIG.modelPath` dans `script.js` pour utiliser un autre nom).

Le modèle doit exporter des morph targets (blendshapes) pour être animé —
voir la section **"Remplacer LuciaHead.glb par un autre avatar"** du
[README principal](../../README.md) pour le détail des exigences et des
instructions.
