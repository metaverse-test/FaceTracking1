/**
 * script.js
 * ---------------------------------------------------------------------------
 * Point d'entrée de l'application. Assemble tous les modules de js/ :
 * scène, caméra, renderer, lumières, avatar, MediaPipe, mapping des
 * blendshapes, animation et contrôles — et pilote l'interface utilisateur.
 *
 * Aucune autre partie du projet ne connaît le nom "LuciaHead.glb" ni aucun
 * nom de mesh ou de blendshape : tout est détecté dynamiquement par
 * js/avatar.js et js/blendshapeMapper.js. Remplacer CONFIG.modelPath
 * ci-dessous suffit à faire fonctionner le projet avec un autre avatar.
 */

import { createScene } from './js/scene.js';
import { createCamera, updateCameraAspect } from './js/camera.js';
import { createRenderer, resizeRenderer } from './js/renderer.js';
import { setupLighting } from './js/lights.js';
import { loadAvatar } from './js/avatar.js';
import { FaceTracker } from './js/mediapipe.js';
import { buildBlendshapeMap } from './js/blendshapeMapper.js';
import { AnimationController } from './js/animation.js';
import { createOrbitControls } from './js/controls.js';
import { createFPSMeter, frameCameraOnObject } from './js/utils.js';

// ============================================================================
// Configuration — les seules valeurs à modifier pour adapter le projet.
// ============================================================================
const CONFIG = {
  // Chemin vers le modèle GLB à charger. Fonctionne avec N'IMPORTE QUEL
  // avatar exportant des blendshapes ARKit : rien d'autre à changer.
  modelPath: 'assets/models/LuciaHead.glb',

  // Environnement HDRI optionnel (reflets réalistes). Mettre `null` pour
  // utiliser l'éclairage studio par défaut (voir js/lights.js).
  hdrPath: null,

  // Si la rotation de tête semble inversée par rapport à vos mouvements
  // une fois testée avec votre avatar, passez cette valeur à `true`.
  mirrorHeadYaw: false,

  // Vitesses de lissage (plus grand = plus réactif/moins lissé).
  blendshapeSmoothing: 22,
  headSmoothing: 14,
  eyeSmoothing: 18,
  eyeMaxAngleDeg: 26,
};

// ============================================================================
// Références DOM
// ============================================================================
const canvas = document.getElementById('app-canvas');
const video = document.getElementById('webcam-feed');
const webcamFrame = document.getElementById('webcam-frame');
const loadingOverlay = document.getElementById('loading-overlay');
const errorBanner = document.getElementById('error-banner');
const btnEnableCamera = document.getElementById('btn-enable-camera');
const btnDisableCamera = document.getElementById('btn-disable-camera');

function setStatusText(key, text) {
  const el = document.querySelector(`[data-text="${key}"]`);
  if (el) el.textContent = text;
}

function setLedState(key, state) {
  const el = document.querySelector(`[data-led="${key}"]`);
  if (el) el.dataset.state = state;
}

function showError(message) {
  console.error(`[App] ${message}`);
  errorBanner.textContent = message;
  errorBanner.hidden = false;
}

// ============================================================================
// Cœur Three.js
// ============================================================================
const scene = createScene();
const camera = createCamera(window.innerWidth / window.innerHeight);
const renderer = createRenderer(canvas);
const controls = createOrbitControls(camera, renderer.domElement);

let avatar = null;
let animationController = null;
let faceTracker = null;
let isCameraActive = false;

// ============================================================================
// Initialisation
// ============================================================================
async function initAvatar() {
  setStatusText('model', 'Chargement…');
  try {
    avatar = await loadAvatar(CONFIG.modelPath);
    scene.add(avatar.root);
    frameCameraOnObject(camera, controls, avatar.root);

    setStatusText('model', avatar.modelName);
    setStatusText('blendshapes', String(avatar.blendshapeNames.size));

    const blendshapeMap = buildBlendshapeMap(avatar.morphMeshes);
    animationController = new AnimationController(avatar, blendshapeMap, {
      blendshapeSmoothing: CONFIG.blendshapeSmoothing,
      headSmoothing: CONFIG.headSmoothing,
      eyeSmoothing: CONFIG.eyeSmoothing,
      eyeMaxAngleDeg: CONFIG.eyeMaxAngleDeg,
      mirrorHeadYaw: CONFIG.mirrorHeadYaw,
    });
  } catch (error) {
    setStatusText('model', 'Erreur');
    showError(
      `Modèle introuvable : "${CONFIG.modelPath}". Ajoutez votre fichier GLB à cet ` +
      'emplacement, ou modifiez CONFIG.modelPath dans script.js (voir README).'
    );
  }
}

async function initMediaPipe() {
  setLedState('mediapipe', 'loading');
  setStatusText('mediapipe', 'Initialisation…');
  try {
    faceTracker = new FaceTracker();
    await faceTracker.init();
    setLedState('mediapipe', 'active');
    setStatusText('mediapipe', 'Prêt');
    btnEnableCamera.disabled = false;
  } catch (error) {
    setLedState('mediapipe', 'error');
    setStatusText('mediapipe', 'Indisponible');
    showError(
      "MediaPipe n'a pas pu s'initialiser (réseau, ou navigateur incompatible " +
      'WebAssembly/WebGL). Le modèle 3D reste consultable, mais le suivi facial est désactivé.'
    );
  }
}

async function init() {
  await setupLighting(scene, renderer, CONFIG.hdrPath);
  await Promise.allSettled([initAvatar(), initMediaPipe()]);
  loadingOverlay.hidden = true;
  requestAnimationFrame(loop);
}

// ============================================================================
// Boucle de rendu
// ============================================================================
const fpsMeter = createFPSMeter();
let lastFrameTime = performance.now();

function loop(nowMs) {
  requestAnimationFrame(loop);

  const deltaSeconds = (nowMs - lastFrameTime) / 1000;
  lastFrameTime = nowMs;

  if (isCameraActive && faceTracker) {
    const result = faceTracker.detect(video, nowMs);
    if (result && animationController) {
      if (result.faceBlendshapes && result.faceBlendshapes.length > 0) {
        animationController.setBlendshapeTargets(result.faceBlendshapes[0].categories);
      }
      if (result.facialTransformationMatrixes && result.facialTransformationMatrixes.length > 0) {
        animationController.setHeadTransform(result.facialTransformationMatrixes[0].data);
      }
    }
  }

  if (animationController) {
    animationController.update(deltaSeconds);
  }

  controls.update();
  renderer.render(scene, camera);

  const fps = fpsMeter(nowMs);
  if (fps !== null) {
    setStatusText('fps', String(fps));
  }
}

// ============================================================================
// Interface utilisateur
// ============================================================================
btnEnableCamera.addEventListener('click', async () => {
  btnEnableCamera.disabled = true;
  setLedState('camera', 'loading');
  setStatusText('camera', 'Démarrage…');

  try {
    await faceTracker.enableCamera(video);
    isCameraActive = true;
    webcamFrame.hidden = false;
    setLedState('camera', 'active');
    setStatusText('camera', 'Active');
    btnDisableCamera.disabled = false;
  } catch (error) {
    setLedState('camera', 'error');
    setStatusText('camera', 'Refusée');
    btnEnableCamera.disabled = false;
    showError(
      "Impossible d'activer la caméra : accès refusé ou aucun périphérique disponible. " +
      "Vérifiez les autorisations caméra de votre navigateur."
    );
  }
});

btnDisableCamera.addEventListener('click', () => {
  faceTracker.disableCamera(video);
  isCameraActive = false;
  webcamFrame.hidden = true;
  setLedState('camera', 'off');
  setStatusText('camera', 'Inactive');
  btnDisableCamera.disabled = true;
  btnEnableCamera.disabled = false;
});

window.addEventListener('resize', () => {
  updateCameraAspect(camera, window.innerWidth, window.innerHeight);
  resizeRenderer(renderer, window.innerWidth, window.innerHeight);
});

// ============================================================================
// Démarrage
// ============================================================================
init();
